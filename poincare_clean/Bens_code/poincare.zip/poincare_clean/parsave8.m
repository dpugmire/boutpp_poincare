% save function used in parfor loop
function parsave8(fname, v1,v2,v3,v4,v5,v6,v7,v8)
  save(fname,'v1','v2','v3','v4','v5','v6','v7','v8')
end
