% save function used in parfor loop
function parsave(fname, v)
  save(fname,'v')
end
